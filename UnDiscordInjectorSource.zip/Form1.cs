using System.IO;
using System.Linq.Expressions;

namespace UnDiscordInjector
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (File.Exists(Environment.GetEnvironmentVariable("USERPROFILE") + @"\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\UnDiscord.bat"))
            {
                label1.Text = "Injected = True";
                button1.Enabled = false;
            }
            else
            {
                label1.Text = "Injected = False";
                button1.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(Environment.GetEnvironmentVariable("USERPROFILE") + @"\AppData\Local\Discord"))
            {
                try {
                    Directory.Delete(Environment.GetEnvironmentVariable("USERPROFILE") + @"\AppData\Local\Discord", true);
                    File.Create(Environment.GetEnvironmentVariable("USERPROFILE") + @"\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\UnDiscord.bat").Dispose();
                    File.WriteAllText(Environment.GetEnvironmentVariable("USERPROFILE") + @"\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\UnDiscord.bat", "@title UnDiscord && cd %userprofile% && cd appdata && cd local && rmdir Discord /s /q");
                } catch (IOException io)
                {
                    MessageBox.Show("Error trying to inject UnDiscord: " + io, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(1);
                }
                MessageBox.Show("UnDiscord has successfully been injected.", "Finished", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                label1.Text = "Injected = True";
                button1.Enabled = false;
            }
            else
            {
                MessageBox.Show("Either Discord is not installed, or it's in a different directory.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
        }
    }
}